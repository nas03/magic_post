import Header from "./Header"
import About from "./About"
import Features from "./Features"
import Feedback from "./Feedback"
import Footer from "./Footer"
import Gallery from "./Gallery"
import Intro from "./Intro"
export {
    Header,
    About,
    Features,
    Feedback,
    Footer,
    Gallery,
    Intro
}
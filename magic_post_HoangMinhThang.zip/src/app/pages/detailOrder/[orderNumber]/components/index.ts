import HorizontalLinearAlternativeLabelStepper from "./HorizontalLinearAlternativeLabelStepper"

export {
    HorizontalLinearAlternativeLabelStepper
}
export const updateTableGather = (typeTable) => ({
    type: "UPDATETABLEGATHER",
    tableType: typeTable
})
